<?php
class appoinmentmodel  extends CI_Model
{
    public function appoinmentmodel ()
        {
        parent::__construct();
        }
    public function index()
    {
    }        
}

