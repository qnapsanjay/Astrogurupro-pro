
<div class="container-fluid">
    <div class="col-lg-12 col-xs-12 col-sm-12 col-md-6">
        <div class="breadcrumbs container-fluid">
            <a href="users">Home</a> &nbsp;/&nbsp; <span>Terms & Condition</span>
           
        </div>  
    </div>  
</div>
<h1 style="min-height: 400px;" class="text-center text-danger">terms and condition</h1>