<?php $this->load->view('header');?>
<div class="product-header row">
    <div class=" col-lg-12 col-xs-12 col-sm-12 col-md-12">
<!--       <h2 class="text-center text-warning">Product & Remedies</h2>-->
    </div>    
    <div class="breadcrumbs container-fluid">
            <a href="users">Home</a> &nbsp;/&nbsp; <span>Product & Remedies</span>
    </div>
</div>
<div class="row product-search">
    <form name="product_serch" method="post" action="<?php echo base_url() ?>users/product_search">
        <input type="text" name="product_name" id="product_name" placeholder="Product Search" class=" col-lg-3 col-lg-offset-7 col-xs-offset-1 col-md-offset-8 col-xs-10 col-sm-offset-7 col-sm-4 col-md-3" required/>
        <button type="submit" class="btn btn-danger fa fa-search"> Search</button>
    </form>  
</div>
<div class="row  ">
    <div class="col-lg-2 col-md-2 col-sm-2 col-xs-12 product_categories row-offcanvas row-offcanvas-left ">
        <h3 class="text-center text-danger ">Categories</h3>   
        <ul class="">
        <?php foreach ($categories as $item):?>
            <li class="btn btn-default"><a href="<?php echo base_url() ?>users/product_list/<?php echo $item->id; ?>"><i class="fa fa-fw fa-compass"></i><?php echo $item->name;?></a></li>
        <?php endforeach;?>
        </ul>
    </div>  
    <div class="product-list col-lg-10 col-md-10 col-sm-10 col-xs-12">   
    <ul>
        <?php if ($list == false): ?>
        <?php echo 'no record found';?>
        <?php else: ?>
         <?php foreach ($list as $item):?>
        <li class="col-lg-4 col-md-4 col-sm-6 col-xs-12 ">      
            <div class="thumbnail">
                 <img src="<?php echo base_url().$item->image_url;?>" alt="" class="img-rounded"/>
                  <div class="caption">
                      <h3 class="text-center"><?php echo $item->name;?></h3><i class="fa fa-fw fa-rupee ">&nbsp;<?php echo $item->rate;?></i>
                    <p><?php echo $item->description;?></p>
                     <a href="#" class="btn " data-toggle="modal" data-target="#mymodel">MORE INFO</a> 
                     <a href="#" class="btn " >ADD TO CARD</a> 
                  </div>
            </div>
        </li>    
       <?php endforeach;?>
        <?php endif; ?>
     </ul>
    </div>    
  </div>
<div class="row">  
 <div class="col-lg-offset-5 col-md-offset-4 col-sm-offset-4 col-xs-offset-1  ">
<ul class="pagination pagination-lg pagination-xs pagination-md pagination-xs ">
  <li><a href="#">&laquo;</a></li>
  <li><a href="#">1</a></li>
  <li><a href="#">2</a></li>
  <li><a href="#">3</a></li>
  <li><a href="#">4</a></li>
  <li><a href="#">5</a></li>
  <li><a href="#">&raquo;</a></li>
</ul>  
</div>
</div>

 <div class="modal fade product-list" id="mymodel" tabindex="-1" role="dialog" 
    aria-labelledby="myModalLabel" aria-hidden="true">
 <div class="modal-dialog" style="width:90%;">
 <div class="modal-content" style="width: 98%;">
 <div class="modal-header">
 <button type="button" class="close" data-dismiss="modal" aria-hidden="true">
     &times;
 </button>
 <h4 class="modal-title" id="myModalLabel">
  Product Name 
 </h4>
 </div>
 <div class="modal-body ">
 <div class="row ">
 <div class="col-lg-3 col-xs-12 col-sm-12 col-md-6">
  <img src="assets/images/productlist/product.jpg" alt="" class="img-rounded"/>
 </div>   
 <div class="col-lg-9 col-xs-12 col-sm-12 col-md-6 text-left text-info">
   <h4 >DIAMOND</h4>
 <p>Space diamonds
See also: Aggregated diamond nanorod Primitive interstellar meteorites were found to contain carbon possibly in the form of diamond (Lewis et al. 1987).[15] Not all diamonds found on Earth originated here. A type of diamond called carbonado that is found in South America and Africa may have been deposited there via an asteroid impact (not formed from the impact) about 3 billion years ago. These diamonds may have formed in the intrastellar environment, but as of 2008, there was no scientific consensus on how carbonado diamonds originated.[16][17]
Diamonds can also form under other naturally occurring high-pressure conditions. Very small diamonds of micrometer and nanometer sizes, known as microdiamonds or nanodiamonds respectively, have been found in meteorite impact craters. Such impact events create shock zones of high pressure and temperature suitable for diamond formation. Impact-type microdiamonds can be used as an indicator of ancient impact craters.[12] Popigai crater in Russia may have the world's largest diamond deposit, estimated at trillions of carats, and formed by an asteroid impact.[18]
Scientific evidence indicates that white dwarf stars have a core of crystallized carbon and oxygen nuclei. The largest of these found in the universe so far, BPM 37093, is located 50 light-years (4.7×1014 km) away in the constellation Centaurus. A news release from the Harvard-Smithsonian Center for Astrophysics described the 2,500-mile (4,000 km)-wide stellar core as a diamond.[19] It was referred to as Lucy, after the Beatles' song "Lucy in the Sky With Diamonds".[20][21]
  </p>
</div> 
</div>  
     <div class="row text-left text-info">
      <p>Diamonds can also form under other naturally occurring high-pressure conditions. Very small diamonds of micrometer and nanometer sizes, known as microdiamonds or nanodiamonds respectively, have been found in meteorite impact craters. Such impact events create shock zones of high pressure and temperature suitable for diamond formation. Impact-type microdiamonds can be used as an indicator of ancient impact craters.[12] Popigai crater in Russia may have the world's largest diamond deposit, estimated at trillions of carats, and formed by an asteroid impact.[18]
Scientific evidence indicates that white dwarf stars have a core of crystallized carbon and oxygen nuclei.
 </p>
     </div>    
</div>
<div class="modal-footer">
<button type="button" class="btn btn-default" data-dismiss="modal">Close
</button>
</div>
</div>    
</div><!-- /.modal-content -->
 </div>
<?php $this->load->view('footer');?>    
      
