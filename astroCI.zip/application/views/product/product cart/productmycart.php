<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
    <head>
        <title>Astrology home page</title>
         <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
        <meta http-equiv="X-UA-Compatible" content="IE=9; IE=8; IE=7; IE=EDGE" />
        <link href="assets/css/jquery-ui.min.css" rel="stylesheet" type="text/css"/>
        <script src="assets/js/jquery.min.js" type="text/javascript"></script>
        <link href="assets/css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
        <link href="assets/css/font-awesome.min.css" rel="stylesheet" type="text/css"/>
        <link href="assets/css/font-awesome.css" rel="stylesheet" type="text/css"/>
        <link href="assets/css/cloud-zoom.css" rel="stylesheet" type="text/css"/>
        <link href="assets/css/app.css" rel="stylesheet" type="text/css"/>
        <script src="assets/lib/jquery-ui.min.js" type="text/javascript"></script>
        <script src="assets/lib/bootstrap.min.js" type="text/javascript"></script>
        <script src="assets/js/cloud-zoom.1.0.3.min.js" type="text/javascript"></script>
        <script src="assets/js/jquery.mockjax.js" type="text/javascript"></script>
 </head>
    
    <body >
        <header >
            <div class="row">
                <div class="logo col-lg-5 col-xs-12 col-sm-3 col-sm-offset-2 col-md-4">
                    <a href="index.html"><p class="text-center">ASTROLOGY</p></a>    
                </div>
            </div>
         </header> 
<div class=" row">
    <div class="col-lg-12 col-xs-12 col-sm-12 col-md-6">
        <div class="breadcrumbs container-fluid">
            <a href="#">Home</a> &nbsp;/&nbsp; <span>ProductMyCart</span>
            <hr></hr>
        </div>  
    </div>  
</div>
        <div class="container productcart thumbnail">
            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                <div class="row">   
                 <a onclick="javascript:;" href='assets/images/productlist/largeimages/productcover.jpg' class ='cloud-zoom xs-hidden' id='zoom1' rel="zoomWidth:600, zoomHeight: 650, adjustX: 16, adjustY:-4">
                  <img src="assets/images/productlist/largeimages/productcover.jpg"  alt="" />
                 </a> 
                </div>  
<!--                <div class="row small-images jumbotron">
                 <a onclick="javascript:;" href="assets/images/productlist/largeimages/productcover1.jpg"  class="img-resposive">
                 <img width="64" data-cloudzoom="useZoom:'#zoom1',image:'assets/images/productlist/largeimages/productcover1.jpg', zoomImage:'images/large/image1.jpg'" alt="" 
                      title="Product Name" src="assets/images/productlist/smallimages/productcover1.jpg" class="img-resposive"/>
                 </a>
                 <a onclick="javascript:;" href="assets/images/productlist/largeimages/productcover1.jpg"  class="img-resposive">
                 <img width="64" data-cloudzoom="useZoom:'#zoom1',image:'assets/images/productlist/largeimages/productcover1.jpg', zoomImage:'images/large/image1.jpg'" alt="" 
                      title="Product Name" src="assets/images/productlist/smallimages/productcover1.jpg" class="img-resposive"/>
                 </a>
                 <a onclick="javascript:;" href="assets/images/productlist/largeimages/productcover1.jpg"  class="img-resposive">
                 <img width="64" data-cloudzoom="useZoom:'#zoom1',image:'assets/images/productlist/largeimages/productcover1.jpg', zoomImage:'images/large/image1.jpg'" alt="" 
                      title="Product Name" src="assets/images/productlist/smallimages/productcover1.jpg" class="img-resposive"/>
                 </a>
                 <a onclick="javascript:;" href="assets/images/productlist/largeimages/productcover1.jpg"  class="img-resposive">
                 <img width="64" data-cloudzoom="useZoom:'#zoom1',image:'assets/images/productlist/largeimages/productcover1.jpg', zoomImage:'images/large/image1.jpg'" alt="" 
                      title="Product Name" src="assets/images/productlist/smallimages/productcover1.jpg" class="img-resposive"/>
                 </a>  
                </div>-->
            </div> 
            
            <div class="product-discription col-lg-6 col-md-6 col-sm-6 col-xs-12">
                <div class="row thumbnail">
                 <div class="col-lg-8 col-md-6 col-sm-8 col-xs-6">
                     <h2>Product Name</h2>
                 </div>
                <div class="col-lg-4 col-md-6 col-sm-4 col-xs-6"> 
                    <h2><i class="fa fa-rupee"></i>&nbsp;<label>399</label></h2>
                </div>   
                </div>
                <div class="row thumbnail">
                    <div class="col-lg-7 col-md-6 col-sm-5 col-xs-4">
                        <h4>Size: <select>
                                <option value="volvo">1</option>
                                <option value="saab">2</option>
                                <option value="mercedes">3</option>
                                <option value="audi">4</option>
                        </select> </h4>
                        <p class="text-danger">
                          To Order On Phone Call:       
                        </p>
                        <p class="text-danger">
                         88888131545     
                        </p>    
                   </div> 
                    <div class="col-lg-5 col-md-6 col-sm-7 col-xs-8">
                        <button class="btn"  id="productid">Purchase Now&nbsp;<i class="fa fa-2x fa-shopping-cart"></i></button> 
                        <h5 class="text-center ">Item code:<label >h4445121</label></h5>
                   </div>
     
                </div>
                <div class="row">
                               <ul id="myTab" class="nav nav-tabs">
                         <li class="active"><a href="#home" data-toggle="tab">
                            About Me</a>
                         </li>
                         <li><a href="#choose" data-toggle="tab">Choose Me</a></li>
                    </ul>
        <div id="myTabContent" class="tab-content" style="border: 1px solid wheat;">
         <div class="tab-pane fade in active" id="home">
            <ul>
                 <li>
                     <label>Color:</label><label>blue</label>
                    
                 </li>  
                <li>
                   <label>Closure:</label><label>blue</label> 
                </li>
                <li>
                   <label>material:</label><label>blue</label> 
                </li>
                   <li>
                   <label>care:</label><label>blue</label>
                </li>  
             </ul>   
        </div>
         <div class="tab-pane fade" id="choose">
         <p>Tutorials Point is a place for beginners in all technical areas. 
         This website covers most of the latest technoligies and explains 
         each of the technology with simple examples. You also have a 
         <b>tryit</b> editor, wherein you can edit your code and 
         try out different possibilities of the examples.</p>
       </div>
   </div>
  </div>
 </div>
</div>  
        
<div class="container small-images jumbotron">
<a onclick="javascript:;" href="assets/images/productlist/largeimages/productcover1.jpg"  class="img-resposive">
<img width="64" data-cloudzoom="useZoom:'#zoom1',image:'assets/images/productlist/largeimages/productcover1.jpg', zoomImage:'images/large/image1.jpg'" alt="" 
title="Product Name" src="assets/images/productlist/smallimages/productcover1.jpg" class="img-resposive"/>
</a>
<a onclick="javascript:;" href="assets/images/productlist/largeimages/productcover1.jpg"  class="img-resposive">
<img width="64" data-cloudzoom="useZoom:'#zoom1',image:'assets/images/productlist/largeimages/productcover1.jpg', zoomImage:'images/large/image1.jpg'" alt="" 
title="Product Name" src="assets/images/productlist/smallimages/productcover1.jpg" class="img-resposive"/>
</a>
<a onclick="javascript:;" href="assets/images/productlist/largeimages/productcover1.jpg"  class="img-resposive">
<img width="64" data-cloudzoom="useZoom:'#zoom1',image:'assets/images/productlist/largeimages/productcover1.jpg', zoomImage:'images/large/image1.jpg'" alt="" 
title="Product Name" src="assets/images/productlist/smallimages/productcover1.jpg" class="img-resposive"/>
</a>
<a onclick="javascript:;" href="assets/images/productlist/largeimages/productcover1.jpg"  class="img-resposive">
<img width="64" data-cloudzoom="useZoom:'#zoom1',image:'assets/images/productlist/largeimages/productcover1.jpg', zoomImage:'images/large/image1.jpg'" alt="" 
title="Product Name" src="assets/images/productlist/smallimages/productcover1.jpg" class="img-resposive"/>
</a>  
</div>
           
<div class="container product-confirm ">
<div class="panel panel-primary">
   <div class="panel-heading">
      <h3 class="panel-title">Currently In Your Shopping Cart</h3>
   </div>
   <div class="panel-body table-responsive">
   <table class="table ">
    <thead>
      <tr >
         <th></th>
         <th>Your Items</th>
         <th>MRP</th>
         <th>QUANTITY</th>
         <th>SIZE</th>
         <th>PRICE</th>
      </tr>
   </thead>
   <tbody>
      <tr>
          <td><img src="assets/images/productlist/smallimages/fh.jpg" class="img-responsive"/></td>
         <td><lable>product name</lable></td>
         <td><lable>399.00</lable></td>
         <td><select>
            <option value="1">1</option>
            <option value="2">2</option>
            <option value="3">3</option>
            <option value="4">4</option>
            </select>
         </td>
         <td><select>
            <option value="1">1</option>
            <option value="2">2</option>
            <option value="3">3</option>
            <option value="4">4</option>
            </select></td>
         <td><lable>399.00</lable></td> 
        </tr>
       
       
   </tbody>
</table>
       <div class="container well ">
        <h4 class="col-lg-offset-7 col-sm-offset-5 col-xs-12" >
         Sub Total:&nbsp;<i class="fa fa-rupee col-lg-offset-2 col-xs-offset-3"></i>&nbsp;<label class="text-center">399.00</label>
        </h4>
       </div>
        <div class="container well">
        <h4 class="col-lg-offset-7 col-md-6 col-sm-offset-5 col-xs-12">
            Shipping Charges:&nbsp;<i class="fa fa-rupee col-lg-offset-2  col-xs-offset-1 col-sm-offset-2">&nbsp;</i><label class="text-center">100.00</label>
        </h4>
        </div>
        <div class="container well">
        <h4 class="col-lg-offset-7 col-md-6 col-sm-offset-5 col-xs-12">
            Order Amount:&nbsp;<i class="fa fa-rupee col-lg-offset-3 col-xs-offset-1 col-sm-offset-2"></i>&nbsp;<label class="text-center">499.00</label>
        </h4>
        </div>
       <div class="container ">
           <div class="">  
<!--         <h5 class=" text-info">For Any Question,call 8888131215</h5> -->
         <button class="btn col-lg-offset-8 col-md-offset-6 col-sm-3 col-sm-offset-6 col-xs-12 "  id="productid">Purchase Now&nbsp;<i class="fa fa-2x fa-shopping-cart"></i></button> 
        </div>
        </div>   
   </div>
</div>   
</div>   
<div class="row">
    <div class="col-lg-12 col-xs-12 col-sm-12 col-md-6">
        <div class="breadcrumbs container-fluid">
            <a href="#">Home</a> &nbsp;/ <span>OrderConformation</span>
            <hr></hr>
        </div>  
    </div>  
</div>
<div class="container">
   <div class="col-lg-12 col-xs-12 col-sm-12 col-md-12">
       <img src="assets/images/conformoreder-nav.png" class="img-responsive" alt=""/>
   </div>  
</div>
<div class="container cunstomer-info">
   <div class="col-lg-12 col-lg-offset-1 col-md-offset-1 col-sm-offset-1 col-xs-12 col-sm-12 col-md-6">
        <form name="customer_details">
       <div class="row">
           <div class="col-lg-2 col-xs-12 col-sm-2 col-md-4">
               <label>PinCode<sup class="text-danger" >*</sup></label>  
           </div>  
           <div class="col-lg-4 col-xs-12 col-sm-6 col-md-8">
               <span> <input type="text" class="form-control" name="pincode" required/></span>
               <span> <p class="text-center">Enter Pincode To select City and State</p></span>
           </div> 
       </div>
       <div class="row">
           <div class="col-lg-2 col-xs-12 col-sm-2 col-md-4">
               <label>Name<sup class="text-danger">*</sup></label>  
           </div>  
           <div class="col-lg-4 col-xs-12 col-sm-6 col-md-8">
                <input type="text" class="form-control" name="name" required/>
           </div> 
       </div>
       <div class="row">
           <div class="col-lg-2 col-xs-12 col-sm-2 col-md-4">
              <label>Address<sup class="text-danger">*</sup></label>   
           </div>  
           <div class="col-lg-4 col-xs-12 col-sm-6 col-md-8">
                <input type="text" class="form-control" name="address" required/>
           </div> 
       </div>
       <div class="row">
           <div class="col-lg-2 col-xs-12 col-sm-2 col-md-4">
               <label>State</label>  
           </div>  
           <div class="col-lg-4 col-xs-12 col-sm-6 col-md-8">
               <label value="" class="form-control" name="state"></label>
           </div> 
       </div>
       <div class="row">
           <div class="col-lg-2 col-xs-12 col-sm-2 col-md-4">
               <label>City<sup class="text-danger">*</sup></label>  
           </div>  
           <div class="col-lg-3 col-xs-12 col-sm-6 col-md-8">
               <select class="form-control" name="city" required>
                   <option>Select City</option>
                   <option></option>
                   <option></option>
               </select>
           </div> 
       </div>
       <div class="row">
           <div class="col-lg-2 col-xs-12 col-sm-2 col-md-4">
               <label>Street<sup class="text-danger">*</sup></label>  
           </div>  
           <div class="col-lg-4 col-xs-12 col-sm-6 col-md-8">
               <input type="text" class="form-control" name="street" required/>
           </div> 
       </div>
       <div class="row">
           <div class="col-lg-2 col-xs-12 col-sm-2 col-md-4">
               <label>Mobile No1<sup class="text-danger">*</sup></label>
            </div>  
           <div class="col-lg-4 col-xs-12 col-sm-6 col-md-8">
               <input type="text" class="form-control" name="mobile1" required/>   
           </div> 
       </div>
        <div class="row">
           <div class="col-lg-2 col-xs-12 col-sm-2 col-md-4">
              <label>Mobile No2</label>
            </div>  
           <div class="col-lg-4 col-xs-12 col-sm-6 col-md-8">
              <input type="text" class="form-control" name="mobile2"/>    
           </div> 
       </div>             
       <div class="row">
           <div class="col-lg-2 col-xs-12 col-sm-2 col-md-4">
               <label>Email<sup class="text-danger">*</sup></label>  
           </div>  
           <div class="col-lg-4 col-xs-12 col-sm-6 col-md-8">
               <input type="email" class="form-control" name="email" required/>
           </div> 
       </div>
       <div class="row">
           <div class="col-lg-6 col-lg-offset-4 col-xs-10 col-xs-offset-4 col-sm-offset-5 col-sm-4 col-md-6">
               <button type="submit" class="btn btn-default">Continoue&nbsp;<i class="fa fa-2x fa-arrow-circle-o-right"></i></button> 
       </div>
   </div> 
       </form>
</div>        
</div>   
<div class="container-fluid">
   <div class="col-lg-12 col-lg-offset-1 col-xs-12 col-sm-12 col-md-12">
       <img src="assets/images/conformoreder-nav1.png" class="img-responsive" alt=""/>
   </div>  
</div>
<div class="container-fluid order-summary">
<div class="col-lg-6 col-lg-offset-1 col-xs-12 col-sm-12 col-md-6">
   <h3>Order Summary</h3>
<div class="table-responsive thumbnail">
   <table class="table">
      <thead>
         <tr>
            <th>Items</th>
            <th>Size</th>
            <th>Quantity</th>
            <th>Amount</th>
         </tr>
      </thead>
      <tbody>
         <tr>
            <td>Product1</td>
            <td>2</td>
            <td>5</td>
            <td>499.00 </td>
         </tr>
      </tbody>  
       <tfoot class="well" >   
         <tr>
             <td><h4>Your Purchase Total:</h4></td>
            <td> </td>
            <td> </td>
            <td><h4>499.00</h4></td>
         </tr>
         <tr>
             <td><h4>Shipping Charges:</h4></td>
            <td> </td>
            <td> </td>
            <td><h4>99.00</h4></td>
         </tr>
          <tr class="">
            <td></td>
            <td> </td>
            <td> <h3>You Pay</h3></td>
            <td><h3><i class="fa fa-rupee"></i>&nbsp;598.00</h3></td>
         </tr>
        </tfoot>      
    
   </table>
</div>      
</div>   
<div class="col-lg-3   col-xs-12 col-sm-12 col-md-6">
    <h3 class="text-center">Shipping Address</h3>
    <div class="thumbnail">
     <label name="name">akash</label></br></br>
     <label name="address" ><abbr>nd 31 basveshwar hudco new nanded.</abbr></label></br>
     <label name="city"><abbr>nanded</abbr></label></br>
     <label name="state"><abbr>maharashtra</abbr></label></br>
     <label name="pincode"><abbr>431603</abbr></label></br>
     <label name="mobile"><abbr>8888131215</abbr></label></br>
   </div>
    <h4 class="text-info"><strong>Order will be Delivered Within 5-7 Days</strong></h4> 
</div>     
</div>   
 <div class="container-fluid cunstomer-info">
 <div class="col-lg-6 col-lg-offset-4 col-xs-10 col-xs-offset-4 col-sm-offset-7 col-sm-4 col-md-4">
   <button type="submit" class="btn btn-default">Conform&nbsp;<i class="fa fa-2x fa-arrow-circle-o-right"></i></button> 
   <a href=""><p class="text-info">Term and Condition<sup>*</sup></p></a>
</div>    
</div> 
        
        
 <div class="container">
   <div class="col-lg-12  col-xs-12 col-sm-12 col-md-12">
       <img src="assets/images/conformoreder-nav3.png" class="img-responsive" alt=""/>
   </div>  
</div>
<div class="container">     
  <div id="tabs">
        <ul>
        <li>
            <a href="#net-banking">Net Banking</a>
        </li>
        <li>
            <a href="#debit-card">Debit Card</a>
        </li>
        <li>
            <a href="#credit-card">Credit Card</a>
        </li>
       
    </ul>
    <div  id="net-banking">
    <div class="container">     
    <p class="col-lg-6 col-xs-8 col-sm-4 col-md-6 text-primary">You have chosen to pay through <strong>Net Banking</strong></p> 
    <p class="col-lg-6 col-xs-12 col-sm-6 col-md-6 text-primary "><strong>Amount payable:<span class="text-danger"><i class="fa fa-rupee"></i>1087</span></strong></p>
    <hr>
    </div>   
     <div class="container">     
      <label class="col-lg-3 col-xs-12 col-sm-4 col-md-3 " for="choose_your_Bank"><strong>Choose Your Bank</strong></label>
       <select class="col-lg-3 col-xs-6 col-sm-4 col-md-3 text-success" name="ddlNetBanking" id="ddlNetBanking">
    <option selected="selected" value="-------Select-------">-------Select-------</option>
	<option value="3">Andhra Bank</option>
	<option value="1">AXIS Bank NetBanking</option>
	<option value="44">Bank of Bahrain &amp; Kuwait</option>
	<option value="5">Bank of Baroda - Corporate Banking</option>
	<option value="6">Bank of Baroda - Retail Banking</option>
	<option value="7">Bank of India</option>
	<option value="38">Bank&nbsp;of Maharashtra</option>
	<option value="36">Canara Bank</option>
	<option value="45">Catholic Syrian Bank</option>
	<option value="46">Central Bank of India</option>
	<option value="8">Citibank Netbanking</option>
	<option value="11">City Union Bank</option>
	<option value="10">Corporation Bank</option>
	<option value="57">DBS</option>
	<option value="12">Deutsche Bank</option>
	<option value="39">Development Credit bank&nbsp;</option>
	<option value="47">Dhanlaxmi Bank</option>
	<option value="13">Federal Bank</option>
	<option value="14">HDFC Bank</option>
	<option value="15">ICICI NetBanking</option>
	<option value="48">IDBI Bank</option>
	<option value="55">Indian Bank</option>
	<option value="19">Indian Overseas Bank</option>
	<option value="18">IndusInd Bank</option>
	<option value="16">Industrial Development Bank of India</option>
	<option value="17">ING Vyasa Bank</option>
	<option value="20">Jammu and Kashmir Bank</option>
	<option value="21">Karnataka Bank Ltd</option>
	<option value="22">Karur Vysya Bank</option>
	<option value="2">Kotak Mahindra Bank</option>
	<option value="23">Lakshmi Vilas Bank</option>
	<option value="49">Laxmi Vilas Bank</option>
	<option value="50">Oriental Bank of Commerce</option>
	<option value="43">Others</option>
	<option value="9">Punjab National Bank - Corporate Banking</option>
	<option value="24">Punjab National Bank - Retail Banking</option>
	<option value="51">Royal Bank of Scotland</option>
	<option value="56">Shamrao Vithal Bank</option>
	<option value="30">South Indian Bank</option>
	<option value="29">Standard Chartered Bank</option>
	<option value="25">State Bank of Hyderabad</option>
	<option value="26">State Bank of India</option>
	<option value="27">State Bank of Mysore</option>
	<option value="35">State Bank Of Patiala</option>
	<option value="28">State Bank of Travancore</option>
	<option value="40">State&nbsp;Bank&nbsp;of Jaipur and Bikaner</option>
	<option value="31">Syndicate Bank</option>
	<option value="32">Tamilnad Mercantile Bank</option>
	<option value="53">The Bank of Rajasthan</option>
	<option value="33">Union Bank of India</option>
	<option value="42">United Bank of India</option>
	<option value="54">Vijaya Bank</option>
	<option value="34">Yes Bank</option>

</select>
</div> 
<div class="container cunstomer-info">
  <p class="col-lg-7 col-xs-7 col-sm-8 col-md-5 " >Click on ‘Pay’ button and you will be directed to a secure gateway for payment. After completing the payment process,
    you will be redirected back to Yepme.com to view details of your order. </p>
 <button type="submit" class="btn col-lg-2  col-xs-6 col-sm-5  col-md-3 ">Pay&nbsp;<i class="fa fa-2x fa-arrow-circle-o-right"></i></button> 
   
</div> 
<div class="container">
<div class="col-lg-9 col-xs-7 col-sm-8 col-md-9 ">
    Note:
<br>
*Please note that if you do not get a payment confirmation and the amount is deducted from your bank account, it will be refunded to your bank account within 48 working hours.<br>
*The amount refunded to you will reflect in your bank account within 7 - 10 working days depending on your bank.   
</div>    
</div>    
</div>

   
<div id="debit-card">
  <div class="container">     
    <p class="col-lg-6 col-xs-8 col-sm-4 col-md-6 text-primary">You have chosen to pay through <strong>Debit Card</strong></p> 
    <p class="col-lg-6 col-xs-12 col-sm-6 col-md-6 text-primary "><strong>Amount payable:<span class="text-danger"><i class="fa fa-rupee"></i>1087</span></strong></p>
    <hr>
    </div>   
     <div class="container">     
      <label class="col-lg-3 col-xs-12 col-sm-4 col-md-3 " ><strong>Choose your Debit Card</strong></label>
       <div class="col-lg-6 col-xs-6 col-sm-4 col-md-3 text-primary" name="" id="">
  <label>
 <input value="DCVisa" name="DC" id="rdbtnDCVisa" class="rdbtnDC" type="radio"/>
 <img src="assets/images/visacard.jpg" alt=""/>
     </label>
 <label>
 <input value="DCMaster" name="DC" id="rdbtnDCMaster" class="rdbtnDC" type="radio"/>
 <img src="assets/images/mastercard.jpg" alt=""/>
 </label>
 <label>
 <input value="DCMastro" name="DC" id="rdbtnDCMastro" class="rdbtnDC" type="radio"/>
 <img src="assets/images/mastrocard.png" alt=""/>
 </label>
 <label>
<input value="DCRupay" name="DC" id="rdbtnDCRupay" class="rdbtnDC" type="radio"/>
<img src="assets/images/rupay.jpg" alt=""/>
 </label>

</div>
</div> 
<div class="container cunstomer-info">
  <p class="col-lg-7 col-xs-7 col-sm-8 col-md-5 " >Please Enter Your Debit Card Details To complete Your Transaction </p>
 <button type="submit" class="btn col-lg-2  col-xs-6 col-sm-5  col-md-3 ">Pay&nbsp;<i class="fa fa-2x fa-arrow-circle-o-right"></i></button> 
   
</div> 
<div class="container">
<div class="col-lg-9 col-xs-7 col-sm-8 col-md-9 ">
    Note:
<br>
*Please note that if you do not get a payment confirmation and the amount is deducted from your bank account, it will be refunded to your bank account within 48 working hours.<br>
*The amount refunded to you will reflect in your bank account within 7 - 10 working days depending on your bank.   
</div>    
</div>      
</div>
<div id="credit-card">
  <div class="container">     
    <p class="col-lg-6 col-xs-8 col-sm-4 col-md-6 text-primary">You have chosen to pay through <strong>Credit Card</strong></p> 
    <p class="col-lg-6 col-xs-12 col-sm-6 col-md-6 text-primary "><strong>Amount payable:<span class="text-danger"><i class="fa fa-rupee"></i>1087</span></strong></p>
    <hr>
    </div>   
     <div class="container">     
      <label class="col-lg-3 col-xs-12 col-sm-4 col-md-3 " ><strong>Choose your Credit Card</strong></label>
       <div class="col-lg-6 col-xs-6 col-sm-4 col-md-3 text-primary" name="" id="">
     <label>
 <input value="DCVisa" name="DC" id="rdbtnDCVisa" class="rdbtnDC" type="radio"/>
 <img src="assets/images/visacard.jpg" alt=""/>
     </label>
 <label>
 <input value="DCMaster" name="DC" id="rdbtnDCMaster" class="rdbtnDC" type="radio"/>
 <img src="assets/images/mastercard.jpg" alt=""/>
 </label>
 <label>
 <input value="DCMastro" name="DC" id="rdbtnDCMastro" class="rdbtnDC" type="radio"/>
 <img src="assets/images/mastrocard.png" alt=""/>
 </label>
 <label>
<input value="DCRupay" name="DC" id="rdbtnDCRupay" class="rdbtnDC" type="radio"/>
<img src="assets/images/rupay.jpg" alt=""/>
 </label>

</div>
</div> 
<div class="container cunstomer-info">
  <p class="col-lg-7 col-xs-7 col-sm-8 col-md-5 " >Please Enter Your Debit Card Details To complete Your Transaction </p>
 <button type="submit" class="btn col-lg-2  col-xs-6 col-sm-5  col-md-3 ">Pay&nbsp;<i class="fa fa-2x fa-arrow-circle-o-right"></i></button> 
   
</div> 
<div class="container">
<div class="col-lg-9 col-xs-7 col-sm-8 col-md-9 ">
    Note:
<br>
*Please note that if you do not get a payment confirmation and the amount is deducted from your bank account, it will be refunded to your bank account within 48 working hours.<br>
*The amount refunded to you will reflect in your bank account within 7 - 10 working days depending on your bank.   
</div>    
</div>  
</div>
</div>  
</div>  
 
<div class="container-fluid">
   <div class="col-lg-12 col-lg-offset-1 col-xs-12 col-sm-12 col-md-12">
       <img src="assets/images/conformoreder-nav -4.png" alt="" class="img-responsive"/>
    </div>  
</div>
<div class="container-fluid order-conformation">
<div class="col-lg-12 col-xs-12 col-sm-12 col-md-12">
   <h3 class="col-lg-offset-1 col-md-6">Order Conformation</h3>
   <div class="container-fluid ">
       <h4 class="col-lg-8 col-xs-12 col-sm-12 col-md-offset-1 col-md-11" >your Order #1011110 has been Successfully Placed.</h4>
   </div>
   <div class="container-fluid">
       <div class="col-lg-4 col-lg-offset-1  col-xs-12 col-sm-6 col-md-6" >
         <h3 class="text-center">Order Summary </h3>
       <div class="thumbnail">
     <abbr>Order No #:</abbr></br>     
     <label name="order_no">1011110</label></br></br>
<abbr>Order Amount</abbr> </br>
     <label name="order_amount" >499.00</label></br></br>
    <abbr>Order Date</abbr></br>
     <label name="order_date">17-08-2014</label></br></br>
<abbr>Payment Method</abbr></br>
     <label name="payment_method">online payment</label></br></br>
<abbr>Expected Delivery</abbr></br>
     <label name="Expected_Delivary">19-08-2014</label></br>
     
   </div>  
       </div>
       <div class="col-lg-4 col-xs-12 col-sm-6 col-md-6" >
       <h3 class="text-center">Shipping To</h3>
       <div class="thumbnail">
     <label name="name">akash</label></br></br>
     <label name="address" ><abbr>nd 31 basveshwar hudco new nanded.</abbr></label></br>
     <label name="city"><abbr>nanded</abbr></label></br>
     <label name="state"><abbr>maharashtra</abbr></label></br>
     <label name="pincode"><abbr>431603</abbr></label></br>
     <label name="mobile"><abbr>8888131215</abbr></label></br>
   </div>
       </div>
   </div>
<div class="container">
  <div class="col-lg-10  col-xs-12 col-sm-12 col-md-6" >
  <div class="table-responsive thumbnail">
   <table class="table">
      <thead>
         <tr>
            <th>Items</th>
            <th>Size</th>
            <th>Quantity</th>
            <th colspan="3">Expected Delivery</th>
         </tr>
      </thead>
      <tbody>
         <tr>
            <td>Product1</td>
            <td>2</td>
            <td>5</td>
            <td colspan="3">19-08-214 </td>
         </tr>
          <tr>
            <td>Product1</td>
            <td>2</td>
            <td>5</td>
            <td >19-08-214 </td>
         </tr>
           <tr>
            <td>Product1</td>
            <td>2</td>
            <td>5</td>
          <td >19-08-214 </td>
         </tr>
      </tbody>  
   </table>
</div>       
</div>  
</div>
</div>  
</div>      
</div>  
        
  <footer>
    <div class="row">
        <div class="col-md-3 widget">
            <h3 class="widget-title text-center">Contact</h3>
            <div class="widget-body text-center">
                <p><br><a href="mailto:#"></a></br></p>	
            </div>
        </div>
        <div class="col-md-3 widget">
            <h3 class="widget-title text-center">Follow me</h3>
            `          <div class="widget-body text-center">
                <p class="follow-me-icons">
                    <a href="#"><img src="assets/images/followme/fb.jpg" alt=""/></a>
                    <a href="#"><img src="assets/images/followme/Twitter-Logo.png" alt=""/></a>
                    <a href="#"><img src="assets/images/followme/linkedin-icon1.png" alt=""/></a>
                </p>	
            </div>
        </div>
        <div class="col-md-6 widget">
            <h3 class="widget-title text-center">Text widget</h3>
            <div class="widget-body text-center">
                <p>information of astrology web site.</p>
            </div>
        </div>
    </div> 
    <div class="row"> 
        <div class="wrap">
            <!---start-copy-right----->
            <div class="copy-right text-center">
                <p style="margin-top: -15px;">Copyright © 2014 &nbsp;<a href="http://atrourl/">Astrology website</a></p>
            </div>
            <!---End-copy-right----->       
        </div>
    </div>
</footer>
<!--<script>
   
      $(".product-discription button").on('click',function(){
          $(.productcart).removeClass();
          $(.product-confirm).addClass().show();
      });
  
</script>-->
<script>
   $(function () {
      $('#myTab li:eq(0) a').tab('show');
   });
</script>
<script type="text/javascript">
CloudZoom.quickStart();

</script>
        <script>
        $('#tabs')
    .tabs()
    .addClass('ui-tabs-vertical ui-helper-clearfix');
        </script>                      
    </body>
</html>
        