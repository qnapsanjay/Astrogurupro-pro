<?php $this->load->view('header');?>
<div class="aboutus container-fluid">
    <div class="col-lg-6col-xs-12 col-sm-12 col-md-6">
        <div class="breadcrumbs container-fluid">
            <a href="users">Home</a> &nbsp;/&nbsp; <span>About Us</span>
           
        </div>      
    <div class="container-fluid">
        <div class="col-lg-offset-1 col-md-offset-1 col-sm-offset-1" >
                    <h1>About Us</h1>
        		<hr>					
                    <p><strong>There are many variations of passages of Lorem Ipsum available.</strong></p>                                 
                  <p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don’t look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn’t anything embarrassing hidden in the middle of text. 
	            <h3>Subtitle</h3>
	           <div class="row-fluid">                      
                   <div class="span10 ">            
                    <p>Lorem ipsum dolor sit amet, consectetueradipiscing elied diam nonummy nibh euisod tincidunt ut laoreet dolore magna aliquam erat volutpatorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat.</p>
                    <p>Lorem ipsum dolor sit amet, consectetueradipiscing elied diam nonummy nibh euisod tincidunt ut laoreet dolore magna aliquam erat volutpatorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat.</p> 
                    </div>		 
                    </div>
                    <hr>
                </div>  
    </div>  
    </div>    
    <div class="owner-profile col-lg-6 col-xs-12 col-sm-12 col-md-5 container ">
        <div class="container">
        <div class="thumbnail col-md-6 col-sm-12 col-lg-6 col-lg-offset-1  col-xs-12 ">
             <img class="col-md-6 col-sm-6 col-lg-6 col-xs-12 img-responsive img-rounded" src="<?php echo base_url();?>assets/images/man1.jpg" alt=""/>
               <div class="col-md-6 col-sm-6 col-lg-6 col-xs-12 " >
                 <h4 >akash malpani</h4>
		 <h5 >Founder and CEO</h5>
                <ul class="social_icons">
                <li><a href="#"><i class="fa fa-facebook"></i></a></li>
		<li><a href="#"><i class="fa fa-twitter"></i></a></li> 
		<li><a href="#"><i class="fa fa-google-plus"></i></a></li>
		</ul>
             </div>
             <div class="col-md-12 col-sm-12 col-lg-12" > 
             <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut  et dolore magna aliqua. Ut enim ad minim veniam</p>       
             </div>
          </div>     
        </div>
        <div class="row team-bar ">
	<div class="first-one-arrow hidden-xs">  
	<i class="fa fa-angle-up"></i>
        <i class="fa fa-angle-down"></i>
	</div>  
        </div>
        <div class=" container">
          <div class="thumbnail col-md-6 col-sm-12 col-lg-6 col-lg-offset-1  col-xs-12">
              <img class="col-md-6 col-sm-6 col-lg-6 col-xs-12 img-responsive img-rounded" src="<?php echo base_url();?>assets/images/man1.jpg" alt=""/>
               <div class="col-md-6 col-sm-6 col-lg-6 col-xs-12 " >
                 <h4 >akash malpani</h4>
		 <h5 >Founder and CEO</h5>
                <ul class="social_icons">
                <li><a href="#"><i class="fa fa-facebook"></i></a></li>
		<li><a href="#"><i class="fa fa-twitter"></i></a></li> 
		<li><a href="#"><i class="fa fa-google-plus"></i></a></li>
		</ul>
             </div>
             <div class="col-md-12 col-sm-12 col-lg-12" > 
             <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut  et dolore magna aliqua. Ut enim ad minim veniam</p>       
             </div>
          </div>     
    </div> 
   </div>     
</div>
<?php $this->load->view('footer');?>