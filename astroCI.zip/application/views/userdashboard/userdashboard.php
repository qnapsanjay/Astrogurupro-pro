<?php $this->load->view('userdashboard/header');   ?> 
</div>
  
<?php $this->load->view('userdashboard/footer');   ?> 
 