<?php $this->load->view('userdashboard/header');   ?> 
<div class="user-content  col-lg-10 col-md-9 col-sm-6 col-xs-12">
         <ul>
         <li> 
              <img src="assets/images/astrologers/Image025.jpg" alt="" class="img-circle img-responsive img-thumbnail"/>   
              <div>
             <p>this is a content of astologer this is a content of astologer this is 
                 a content of astologer this is a content of astologer </p>
             </div>
             <button class="btn" data-toggle="modal" data-target="#myModal">READ MORE</button>            
         </li>
         <li> 
              <img src="assets/images/astrologers/Image025.jpg" alt="" class="img-circle  img-responsive img-thumbnail"/>   
              <div>
             <p>this is a content of astologer this is a content of astologer this is 
                 a content of astologer this is a content of astologer </p>
             </div>
             <button class="btn">READ MORE</button>            
         </li>
         <li> 
              <img src="assets/images/astrologers/Image025.jpg" alt="" class="img-circle  img-responsive img-thumbnail"/>   
              <div>
             <p>this is a content of astologer this is a content of astologer this is 
                 a content of astologer this is a content of astologer </p>
             </div>
            <button class="btn" data-toggle="modal" data-target="#myModal">READ MORE</button>             
         </li>
         <li> 
              <img src="assets/images/astrologers/Image025.jpg" alt="" class="img-circle  img-responsive img-thumbnail"/>   
              <div>
             <p>this is a content of astologer this is a content of astologer this is 
                 a content of astologer this is a content of astologer </p>
             </div>
             <button class="btn" data-toggle="modal" data-target="#myModal">READ MORE</button>            
         </li>
         <li> 
              <img src="assets/images/astrologers/Image025.jpg" alt="" class="img-circle img-thumbnail"/>   
              <div>
             <p>this is a content of astologer this is a content of astologer this is 
                 a content of astologer this is a content of astologer </p>
             </div>
             <button class="btn" data-toggle="modal" data-target="#myModal">READ MORE</button>             
         </li>
         <li> 
              <img src="assets/images/astrologers/Image025.jpg" alt="" class="img-circle img-thumbnail"/>   
              <div>
             <p>this is a content of astologer this is a content of astologer this is 
                 a content of astologer this is a content of astologer </p>
             </div>
             <button class="btn" data-toggle="modal" data-target="#myModal">READ MORE</button>             
         </li>
        </ul>
     </div>  

                        <!-- Modal -->
                <div class="modal fade astrologer-profile" id="myModal" tabindex="-1" role="dialog" 
                            aria-labelledby="myModalLabel" aria-hidden="true">
                    <div class="modal-dialog" style="width:90%;">
                <div class="modal-content" style="width: 98%;">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">
                      &times;
                    </button>
                    <h4 class="modal-title" id="myModalLabel">
                        NIKIL PATIL 
                    </h4>
                </div>
                <div class="modal-body ">
                    <div class="row ">
                        <div class="col-lg-3 col-xs-12 col-sm-12 col-md-6">
                            <img src="assets/images/astrologers/Image025.jpg" class="astrologer-profile-img img-responsive" alt=""/>
                        </div>   
                        <div class="col-lg-9 col-xs-12 col-sm-12 col-md-6">
                             <div data-spy="scroll" data-target="#navbar-example" data-offset="0" 
                            style="height: 375px;overflow:auto; position: relative;">
                            <h4 id="ios">iOS</h4>
                            <p>iOS is a mobile operating system developed and distributed by Apple 
                             Inc. Originally released in 2007 for the iPhone, iPod Touch, and Apple 
                             TV. iOS is derived from OS X, with which it shares the Darwin 
                             foundation. iOS is Apple's mobile version of the OS X operating system 
                            used on Apple computers.
                            </p>
                            <h4 id="svn">SVN</h4>
                            <p>Apache Subversion which is often abbreviated as SVN, is a software 
                                versioning and revision control system distributed under an open source 
                                license. Subversion was created by CollabNet Inc. in 2000, but now it 
                                is developed as a project of the Apache Software Foundation, and as 
                                such is part of a rich community of developers and users.
                            </p>
                            <h4 id="jmeter">jMeter</h4>
                            <p>jMeter is an Open Source testing software. It is 100% pure Java 
                            application for load and performance testing.
                            </p>
                             <h4 id="ejb">EJB</h4>
                             <p>Enterprise Java Beans (EJB) is a development architecture for building 
                              highly scalable and robust enterprise level applications to be deployed 
                              on J2EE compliant Application Server such as JBOSS, Web Logic etc.
                             </p>
                             <h4 id="spring">Spring</h4>
                             <p>Spring framework is an open source Java platform that provides 
                             comprehensive infrastructure support for developing robust Java 
                             applications very easily and very rapidly.
                             </p>
                             <p>Spring framework was initially written by Rod Johnson and was first 
                              released under the Apache 2.0 license in June 2003.
                             </p>
                             <h4 id="jmeter">jMeter</h4>
                            <p>jMeter is an Open Source testing software. It is 100% pure Java 
                            application for load and performance testing.
                            </p>
                             <h4 id="ejb">EJB</h4>
                             <p>Enterprise Java Beans (EJB) is a development architecture for building 
                              highly scalable and robust enterprise level applications to be deployed 
                              on J2EE compliant Application Server such as JBOSS, Web Logic etc.
                             </p>
                             <h4 id="spring">Spring</h4>
                             <p>Spring framework is an open source Java platform that provides 
                             comprehensive infrastructure support for developing robust Java 
                             applications very easily and very rapidly.
                             </p>
                             <p>Spring framework was initially written by Rod Johnson and was first 
                              released under the Apache 2.0 license in June 2003.
                             </p>
                          </div> 
                        </div>    
                    </div>
                    <div class="row">
                        <div class="col-lg-12 col-xs-12 col-md-12 col-sm-12">
                            <h2 class="text-center text-info" style="border-top:1px solid blueviolet;margin-top:5px; ">Chatting Options</h2>
                             <ul class="list-inline text-center" style="border-bottom:1px solid blueviolet;margin-top:10px;">
                                <li>
                                    <a href=""> <img src="assets/images/chattinglogos/email1.jpg" alt=""/></a>
                                  <h4 class="text-center">EMAIL</h4> 
                                </li>
                                 <li>
                                     <a href=""><img src="assets/images/chattinglogos/videochat.png" alt=""/></a>
                                   <h4 class="text-center">Video</h4> 
                                 </li>
                                 <li>
                                     <a href=""><img src="assets/images/chattinglogos/audiochat.png" alt=""/></a>
                                   <h4 class="text-center">Audio</h4> 
                                 </li>  
                                 <li>
                                     <a href=""> <img src="assets/images/chattinglogos/chat.jpg" alt=""/></a>
                                   <h4 class="text-center">Chat</h4> 
                                 </li>  
                             </ul>
                             </div>    
                        </div>
                </div> 
                       <div class="modal-footer">
                        <button type="button" class="btn btn-default" data-dismiss="modal">Close
                        </button>
                </div>
                </div>    
                </div><!-- /.modal-content -->
                </div><!-- /.modal -->
   </div>    
  <?php $this->load->view('userdashboard/footer');   ?> 