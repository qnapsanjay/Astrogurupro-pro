     <footer>
    <div class="row">
        <div class="col-md-3 widget">
            <h3 class="widget-title text-center">Contact</h3>
            <div class="widget-body text-center">
                <p><br><a href="mailto:#"></a></br></p>	
            </div>
        </div>
        <div class="col-md-3 widget">
            <h3 class="widget-title text-center">Follow me</h3>
            `          <div class="widget-body text-center">
                <p class="follow-me-icons">
                    <a href="#"><img src="assets/images/followme/fb.jpg" alt=""/></a>
                    <a href="#"><img src="assets/images/followme/Twitter-Logo.png" alt=""/></a>
                    <a href="#"><img src="assets/images/followme/linkedin-icon1.png" alt=""/></a>
                </p>	
            </div>
        </div>
        <div class="col-md-6 widget">
            <h3 class="widget-title text-center">Text widget</h3>
            <div class="widget-body text-center">
                <p>information of astrology web site.</p>
            </div>
        </div>
    </div> 
    <div class="row"> 
        <div class="wrap">
            <!---start-copy-right----->
            <div class="copy-right text-center">
                <p style="margin-top: -15px;">Copyright © 2014 &nbsp;<a href="http://atrourl/">Astrology website</a></p>
            </div>
            <!---End-copy-right----->       
        </div>
    </div>
</footer>     
    </body>
</html> 