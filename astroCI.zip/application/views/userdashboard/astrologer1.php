<?php $this->load->view('userdashboard/header');   ?> 
<div class="user-content  col-lg-10 col-md-9 col-sm-6 col-xs-12">
         <ul>
         <li> 
              <img src="assets/images/astrologers/Image025.jpg" alt="" class="img-circle img-thumbnail"/>   
              <div>
             <p>this is a content of astologer this is a content of astologer this is 
                 a content of astologer this is a content of astologer </p>
             </div>
             <button class="btn" data-toggle="modal" data-target="#myModal">READ MORE</button>            
         </li>
         <li> 
              <img src="assets/images/astrologers/Image025.jpg" alt="" class="img-circle img-thumbnail"/>   
              <div>
             <p>this is a content of astologer this is a content of astologer this is 
                 a content of astologer this is a content of astologer </p>
             </div>
             <button class="btn">READ MORE</button>            
         </li>
         <li> 
              <img src="assets/images/astrologers/Image025.jpg" alt="" class="img-circle img-thumbnail"/>   
              <div>
             <p>this is a content of astologer this is a content of astologer this is 
                 a content of astologer this is a content of astologer </p>
             </div>
            <button class="btn" data-toggle="modal" data-target="#myModal">READ MORE</button>             
         </li>
         <li> 
              <img src="assets/images/astrologers/Image025.jpg" alt="" class="img-circle img-thumbnail"/>   
              <div>
             <p>this is a content of astologer this is a content of astologer this is 
                 a content of astologer this is a content of astologer </p>
             </div>
             <button class="btn" data-toggle="modal" data-target="#myModal">READ MORE</button>            
         </li>
         <li> 
              <img src="assets/images/astrologers/Image025.jpg" alt="" class="img-circle img-thumbnail"/>   
              <div>
             <p>this is a content of astologer this is a content of astologer this is 
                 a content of astologer this is a content of astologer </p>
             </div>
             <button class="btn" data-toggle="modal" data-target="#myModal">READ MORE</button>             
         </li>
         <li> 
              <img src="assets/images/astrologers/Image025.jpg" alt="" class="img-circle img-thumbnail"/>   
              <div>
             <p>this is a content of astologer this is a content of astologer this is 
                 a content of astologer this is a content of astologer </p>
             </div>
             <button class="btn" data-toggle="modal" data-target="#myModal">READ MORE</button>             
         </li>
        </ul>
       </div>
<?php $this->load->view('userdashboard/footer');   ?> 
        