<?php $this->load->view('userdashboard/header');   ?> 
<div class="user-profile col-lg-5 col-md-5 col-sm-7 col-xs-12"> 
    <div class="view-profile panel panel-info">
        <div class="panel-heading">
           <h3 class="panel-title">
            USER PROFILE
            </h3>
        </div>
        <div class="panel-body ">
        <strong><lable>NAME:</lable><lable></lable></strong></br>
        <strong><lable>EMAIL:</lable><lable></lable></strong></br>
        <strong><lable>MOBILE No.:</lable><lable></lable></strong></br>
        <strong> <lable>Gender:</lable><lable></lable></strong></br>
        <strong> <lable>Birth Date:</lable><lable></lable></strong></br>
        <strong> <lable>Birth Time:</lable><lable></lable></strong></br>
        <strong><lable>Birth Place:</lable><lable></lable></strong></br>
        </div>
     </div>                                      
 </div>
<?php $this->load->view('userdashboard/footer');   ?> 