$(function() {
    $("#birthday").datetimepicker({
        changeMonth: true,
        changeYear: true,
        timeFormat: "hh:mm tt",
        maxDate:0
    });   
});


